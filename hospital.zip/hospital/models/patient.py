from odoo import models,fields,api,_
from odoo.exceptions import ValidationError
import random

class Patient(models.Model):
    _name = 'hospital.patient'
    # _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Patients'
    _rec_name = 'name'

    # def set_default_contact(self):
    #     self.contact = random.randint(0,1000000)
    name = fields.Char(string = 'Patient Name')
    age = fields.Integer(string = 'Patient Age')
    gender = fields.Selection([
        ('male','Male'),
        ('female','Female')
    ])
    random_variable = random.randint(0,1000000)
    res = lambda number: number
    contact = fields.Char('Contact Number',required = True,default = str(res(random_variable)))
    notes = fields.Text('Notes About Case')
    diagnose_id = fields.Many2one('hospital.specialism')
    doctor_id = fields.Many2one('hospital.doctor',string = 'Related Doctor')
    doctor_gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female')
    ],compute = '_prevent_mixing')
    secuence = fields.Char(string='Patient_ID', required=True, copy=False,
                           readonly=True, index=True, default=lambda self: _('New'))
    image_1920 = fields.Binary('Image')
    patient_name_upper = fields.Char(compute='compute_upper_name',inverse = 'compute_lower_name',string='Upper Name')

    _sql_constraints = [
        ('name_uniq', 'UNIQUE (name)', 'The company name must be unique !')
    ]
    @api.depends('name')
    def compute_upper_name(self):
        for rec in self:
            rec.patient_name_upper = rec.name.upper() if rec.name else False

    def compute_lower_name(self):                           # difference between self and rec(loop)
        for rec in self:
            rec.name = rec.patient_name_upper.lower() if rec.patient_name_upper else False


    # def open_doctors_related(self):
    #     return {
    #         'name': _('Doctors'),
    #         'domain': [],
    #         'res_model': 'hospital.doctor',
    #         'view_type':'form',
    #         'view_id':False,
    #         'view_mode':'tree,form',
    #         'type': 'ir.actions.act_window',
    #     }
    @api.model
    def create(self, vals):
        if vals.get('secuence', _('New')) == _('New'):
            vals['secuence'] = self.env['ir.sequence'].next_by_code('hospital.patient.secuence') or _('New')
        result = super(Patient, self).create(vals)
        return result

    @api.onchange('doctor_id')
    def set_doctor_gender(self):
        if self.doctor_id:
            self.doctor_gender = self.doctor_id.gender

    @api.constrains('contact')
    def _check_patient_country(self):
        if len(str(self.contact)) < 6:
            raise ValidationError(_('contact invalid data'))

    @api.depends('gender')
    def _prevent_mixing(self):
        self.doctor_gender = self.gender

    def action_patients(self):
        return {
            'name': _('Patients Server Action'),
            'domain': [],
            'res_model':'hospital.patient',
            'view_type':'form',
            'view_id': False,
            'view_mode':'tree,form',
            'type':'ir.actions.act_window',
        }