import datetime

from odoo import models,fields,api,_

class Appointment(models.Model):
    _name = 'hospital.appointment'
    _description = 'appointments'
    _rec_name = 'appointment'

    appointment = fields.Date(string ='Appointments')
    # doctor_id = fields.Many2one('hospital.doctor')
    def open_doctor_appoiontment(self):
        return {
            'name': _('Doctors'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.doctor',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'domain':[('name_id','=','self.id')]
        }