from odoo import models,fields,api

class Specialism(models.Model):
    _name = 'hospital.specialism'
    _description = 'specialisms'

    name = fields.Char('Availble Specialisms')
    _sql_constraints = [
        ('name_uniq', 'unique (name)', "Special name already exists !"),
    ]