from odoo import models,fields,api,_

class CreateFromOutside(models.Model):
    _name = 'hospital.create.fu'
    _description = 'create'
    # _rec_name = 'appointment'

    notes = fields.Text('Which Model Do You Open ?')

    def open_appointments(self):
        for rec in self.env['hospital.appointment'].search([('id','=',11)]):
            print(rec.appointment)
