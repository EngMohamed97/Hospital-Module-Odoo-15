from odoo import models,fields,api,_
import odoo.exceptions
import random


class Doctor(models.Model):
    _name = 'hospital.doctor'
    _description = 'Doctors'
    _rec_name = 'name_id'

    name_id = fields.Many2one('res.partner', string = 'Doctor Name')
    specialism_id = fields.Many2one("hospital.specialism", string="Specialism")
    random_variable = random.randint(0, 1000000)
    res = lambda number: number
    contact = fields.Char('Contact Number', required=True, default = '02'+str(res(random_variable)))
    notes = fields.Text('Notes About Case')
    appointment_ids = fields.Many2many('hospital.appointment','doctor_id')
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female')
    ])
    state = fields.Selection([
        ('draft', 'Draft'),
        ('cancel', 'Cancelled'),
        ('confirm', 'Confirmed'),
        ('validate', 'Validated'),
        ('done', 'Done')
    ], 'Status', default='draft', index=True, required=True, readonly=True, copy=False)

    @api.constrains('contact')
    def _check_nationality(self):
        if self.contact.startswith('02') == False:
            raise exceptions.ValidationError(_('Doctor Must Be Egyptian'))


    # def name_get(self):
    #     res = []
    #     for rec in self:
    #         name = "%s (%s)" % (rec.name_id, rec.specialism_id)
    #         res += [(rec.id, name)]
    #     return res