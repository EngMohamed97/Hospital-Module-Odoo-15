from odoo import models,fields,api

class Wizard(models.TransientModel):
    _name = 'hospital.wizard'
    _description = 'Wizard Descripion'

    def _current_special(self):
        return self.env['hospital.appointment'].browse(self.env.context.get('active_ids'))

    appointment_id = fields.Many2one('hospital.appointment',default = _current_special)

    def cancel_appointment(self):
        return

